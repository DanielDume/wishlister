create database if not exists QuizAppDb;
use QuizAppDb;
create table if not exists testTable (a int, b varchar(20));
